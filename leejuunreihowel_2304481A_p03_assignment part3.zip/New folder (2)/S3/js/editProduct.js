function getProduct(productId, callback) {
    if (!productId) {
        console.error('Product ID is missing');
        return;
    }

    var request = new XMLHttpRequest();
    request.open('GET', 'https://api.example.com/products/' + productId, true);

    request.onload = function() {
        if (request.status >= 200 && request.status < 400) {
            var product = JSON.parse(request.responseText);
            if (product) {
                callback(product);
            } else {
                console.error('Product not found');
            }
        } else {
            console.error('Error fetching product. Status code: ' + request.status);
        }
    };

    request.onerror = function() {
        console.error('Failed to fetch product');
    };

    request.send();
}

document.addEventListener("DOMContentLoaded", function() {
    var urlParams = new URLSearchParams(window.location.search);
    var productId = urlParams.get('id');

    if (productId) {
        getProduct(productId, function(product) {
            document.getElementById("edit-productid").value = productId;
            document.getElementById("edit-productname").value = product.productname;
            document.getElementById("edit-productprice").value = product.productprice;
        });
    } else {
        console.error('Product ID not found in URL parameters');
    }
});
