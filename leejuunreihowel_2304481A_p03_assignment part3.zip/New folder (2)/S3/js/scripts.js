// Function to add a new product
function addProduct() {
    var response = "";

    // Retrieve the existing products from sessionStorage
    var products = JSON.parse(sessionStorage.getItem("products"));

    // Create a new product object
    var jsonData = new Object();
    jsonData.productid = document.getElementById("productid").value;
    jsonData.productname = document.getElementById("productname").value;
    jsonData.productprice = document.getElementById("productprice").value;

    // Check if all fields are filled
    if (jsonData.productid == "" || jsonData.productname == "" || jsonData.productprice == ""){
        alert('All fields are required!'); 
        return;
    }

    // Create a new XMLHttpRequest to send the product data
    var request = new XMLHttpRequest();

    // Set up the POST request
    request.open("POST", "https://nxzx2rgml0.execute-api.us-east-1.amazonaws.com/product", true);

    // Define what to do when the request is loaded
    request.onload = function() {
        response = JSON.parse(request.responseText);
        console.log(response);

        // Check the response message
        if (response.message == "product added") {
            alert('Product added.');
            location.reload(); // Reload the page to show the new product
        } else {
            alert('Error. Unable to post');
        }
    };

    // Send the product data as JSON
    request.send(JSON.stringify(jsonData));
}

// Function to get a product by its ID
function getProduct(productid, callback) {
    var request = new XMLHttpRequest();
    request.open("GET", `https://nxzx2rgml0.execute-api.us-east-1.amazonaws.com/product/${productid}`, true);

    // Define what to do when the request is loaded
    request.onload = function() {
        if (request.status >= 200 && request.status < 400) {
            try {
                var response = JSON.parse(request.responseText);

                if (response.Items && response.Items.length > 0) {
                    var product = response.Items[0];

                    // Display the product details in the modal
                    var productIdElement = document.querySelector("#productId");
                    var productNameElement = document.querySelector("#productName");
                    var productPriceElement = document.querySelector("#productPrice");

                    if (productIdElement && productNameElement && productPriceElement) {
                        productIdElement.textContent = product.productid;
                        productNameElement.textContent = product.productname;
                        productPriceElement.textContent = product.productprice;
                    } else {
                        console.error("Product elements not found");
                    }
                } else {
                    console.error("Product not found");
                }
            } catch (e) {
                console.error("Error parsing response JSON:", e);
            }
        } else {
            console.error("Error loading product:", request.status, request.statusText);
            console.error("Response:", request.responseText);
        }
    };

    // Send the request
    request.send();
}

// Function to delete a product by its ID
function deleteProduct(productId) {
    var request = new XMLHttpRequest();

    // Set up the DELETE request
    request.open("DELETE", "https://nxzx2rgml0.execute-api.us-east-1.amazonaws.com/product/" + productId, true);

    // Define what to do when the request is loaded
    request.onload = function(){
        if (request.status >= 200 && request.status < 400) {
            var response = JSON.parse(request.responseText);

            if (response.affectedRows == 1) {
                alert('Product deleted');
                location.reload(); // Reload the page to remove the deleted product
            } else {
                alert('Error deleting the product');
                location.reload();
            }
        } else {
            console.error("Error deleting product:", request.status, request.statusText);
            console.error("Response:", request.responseText);
        }
    };

    // Send the request
    request.send();
}

// Function to edit a product
function editProduct(productId) {
    var productNameElement = document.getElementById(`edit-productname-${productId}`);
    var productPriceElement = document.getElementById(`edit-productprice-${productId}`);
    window.location.href = `editproduct.html?id=${productId}`;

    console.log(productNameElement);
    console.log(productPriceElement);

    if (!productNameElement || !productPriceElement) {
        console.error("Product elements not found");
        return;
    }

    var productName = productNameElement.innerText;
    var productPrice = productPriceElement.innerText;

    // Create input fields for editing
    productNameElement.innerHTML = `<input type="text" id="edit-productname-${productId}" value="${productName}">`;
    productPriceElement.innerHTML = `<input type="text" id="edit-productprice-${productId}" value="${productPrice}">`;

    // Change the button to Save
    var editButton = document.getElementById(`edit-button-${productId}`);
    if (editButton) {
        editButton.innerHTML = "Save";
        editButton.setAttribute("onclick", `saveProductChanges(${productId})`);
    }
}

// Function to save product changes
async function saveProductChanges(productId) {
    var editedProductName = document.getElementById(`edit-productname-${productId}`);
    var editedProductPrice = document.getElementById(`edit-productprice-${productId}`);

    if (!editedProductName || !editedProductPrice) {
        console.error("Edited product details not found");
        return;
    }

    var productName = editedProductName.value;
    var productPrice = editedProductPrice.value;

    // Update the edited values on the screen
    var productNameElement = document.getElementById(`product-name-${productId}`);
    var productPriceElement = document.getElementById(`product-price-${productId}`);

    if (productNameElement && productPriceElement) {
        productNameElement.innerHTML = productName;
        productPriceElement.innerHTML = productPrice;

        // Change the button back to Edit
        var editButton = document.getElementById(`edit-button-${productId}`);
        if (editButton) {
            editButton.innerHTML = "Edit";
            editButton.setAttribute("onclick", `editProduct(${productId})`);
        }

        // Make API call to update the product details in the backend
        try {
            const response = await updateProductDetails(productId, productName, productPrice);
            if (response && response.affectedRows == 1) {
                alert('Product details updated successfully');
            } else {
                alert('Error updating product details');
            }
        } catch (error) {
            console.error("Error updating product details:", error);
            alert('An error occurred while updating product details');
        }
    } else {
        console.error("Product elements not found");
    }
}

// Function to make an API call to update product details
function updateProductDetails(productId, productName, productPrice) {
    return new Promise((resolve, reject) => {
        var request = new XMLHttpRequest();
        request.open("PUT", `https://nxzx2rgml0.execute-api.us-east-1.amazonaws.com/product/${productId}`, true);
        request.setRequestHeader('Content-Type', 'application/json');

        // Define what to do when the request is loaded
        request.onload = function () {
            if (request.status >= 200 && request.status < 400) {
                resolve(JSON.parse(request.responseText));
            } else {
                reject(new Error("Error updating product details"));
            }
        };

        // Send the updated product data as JSON
        request.send(JSON.stringify({ productname: productName, productprice: productPrice }));
    });
}
